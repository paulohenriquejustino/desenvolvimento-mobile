
import 'dart:io';

// Criando minha função void
void somas(int numero1, int numero2) {
  print('-'*70);

  int adicao = numero1 + numero2;
  int subtracao = numero1 - numero2;
  int multiplicacao = numero1 * numero2;
  int divisao = numero1 ~/ numero2;
  int restoDivisao = numero1 % numero2;
  
  print('Soma: $adicao');
  print('Subtração: $subtracao');
  print('Multiplicação: $multiplicacao');
  print('Divisão: $divisao');
  print('Resto divisão: $restoDivisao');

}

void main() {
  bool flag = true;

  while (flag) {
    print('1 - Realizar Operações Aritimeticas ');
    print('2 - Finalizar programa ');

    int opcao = int.parse(stdin.readLineSync()!);

    switch(opcao) {
      case 1:
      print('-'*70);
      stdout.write('Digite o primeiro número inteiro: ');
      int numero1 = int.parse(stdin.readLineSync()!);
      print('');
      stdout.write('Digite o segundo número inteiro: ');
      int numero2 = int.parse(stdin.readLineSync()!);
      print('');

      // invocando a função
      somas(numero1, numero2);
      break;
      case 2:
        print('Finalizando programa...');
        flag = false;
        break;
      default:
        print('Opção inválida. Tente novamente.');
        break;
    }
  }
}