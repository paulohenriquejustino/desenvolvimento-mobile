import 'dart:io';

void mediaAlunos(List<int> lista) {
  int somanota = lista.reduce((a, b) => a + b);
  double media = somanota / lista.length;
  print('-'*70);
  print('Média: $media');
}


void main() {
  bool flag = true;
  List<int> lista = [];

  while (flag) {
    print('1 - Digite 4 números ');
    print('2- Mostrar a média ');
    print('3 - Finalizar programa... ');

    int opcao = int.parse(stdin.readLineSync()!);

    switch(opcao) {
      case 1:
        for (int i = 0; i < 4; i++) {
          stdout.write('Digite um número inteiro: ');
          int numero1 = int.parse(stdin.readLineSync()!);
          lista.add(numero1);
        }
        break;

      case 2:
        if (lista.length == 4) {
          mediaAlunos(lista);
        } else {
          print('É preciso digitar 4 números antes de calcular a média.');
        }
        break;

      case 3:
        print('Finalizando programa...');
        flag = false;
        break;

      default:
        print('Opção inválida. Tente novamente.');
        break;
    }
  }
}
