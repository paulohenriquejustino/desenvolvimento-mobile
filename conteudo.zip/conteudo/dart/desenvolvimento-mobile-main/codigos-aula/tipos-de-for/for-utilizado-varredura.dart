import 'dart:io';

void main() {
  //Lista do tipo String
  List<String> pantera76 = [
    'Kelly Garrett',
    'Jill Munroe',
    'Sabrina Duncan'

  ];

  for (String persongem in pantera76) {
    print(persongem);
  }
}