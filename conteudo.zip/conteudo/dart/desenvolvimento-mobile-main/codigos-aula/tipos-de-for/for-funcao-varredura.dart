import 'dart:io';

void main() {
  //Lista tipo string
  List<String> panteras76 = [
    'Jaclyn Smith',
    'Ferrah Fawcett',
    'Kate Jackson'
  ];

  panteras76.forEach((atriz) {
    print(atriz);//element é um nome padrão, mas pode ser alterado
  });
}